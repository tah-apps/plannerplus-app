package ir.plannerplus.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/** Keeps the list of upcoming alarms and reminders in sync with AlarmManager. */
public class Scheduler {
    static final String PREFS = "pp_native";
    static final String K_SCHEDULE = "schedule";
    static final String K_IDS = "ids";

    public static void apply(Context c, String json) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(K_SCHEDULE, json).apply();
        schedule(c, json);
    }

    public static void reschedule(Context c) {
        String json = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_SCHEDULE, "[]");
        schedule(c, json);
    }

    private static void schedule(Context c, String json) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        Set<String> old = sp.getStringSet(K_IDS, new HashSet<String>());
        for (String id : old) {
            PendingIntent pi = pending(c, id, null, null, null, PendingIntent.FLAG_NO_CREATE);
            if (pi != null) {
                am.cancel(pi);
                pi.cancel();
            }
        }

        Set<String> ids = new HashSet<String>();
        try {
            JSONArray arr = new JSONArray(json);
            long now = System.currentTimeMillis();
            Intent open = new Intent(c, MainActivity.class);
            PendingIntent show = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                long at = o.getLong("at");
                if (at <= now) continue;
                String id = o.getString("id");
                PendingIntent pi = pending(c, id, o.optString("title"), o.optString("body"),
                        o.optString("type", "task"), PendingIntent.FLAG_UPDATE_CURRENT);
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
                ids.add(id);
            }
        } catch (Exception ignored) { }
        sp.edit().putStringSet(K_IDS, ids).apply();
    }

    private static PendingIntent pending(Context c, String id, String title, String body, String type, int flag) {
        Intent in = new Intent(c, AlarmReceiver.class);
        in.setAction("pp.fire." + id);
        if (title != null) {
            in.putExtra("id", id);
            in.putExtra("title", title);
            in.putExtra("body", body);
            in.putExtra("type", type);
        }
        return PendingIntent.getBroadcast(c, id.hashCode(), in, flag | PendingIntent.FLAG_IMMUTABLE);
    }
}
