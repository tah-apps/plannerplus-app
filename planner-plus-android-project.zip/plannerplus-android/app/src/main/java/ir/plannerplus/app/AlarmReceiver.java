package ir.plannerplus.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;

public class AlarmReceiver extends BroadcastReceiver {
    static final String CH_ALARM = "pp_alarm_v1";
    static final String CH_TASK = "pp_task_v1";

    @Override
    public void onReceive(Context c, Intent in) {
        String title = in.getStringExtra("title");
        if (title == null) return;
        String body = in.getStringExtra("body");
        String type = in.getStringExtra("type");
        String id = in.getStringExtra("id");

        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        createChannels(nm);

        boolean alarm = "alarm".equals(type);
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(c, 1, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = new Notification.Builder(c, alarm ? CH_ALARM : CH_TASK)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setColor(0xFF7B2FF7)
                .setContentIntent(content);
        if (alarm) b.setCategory(Notification.CATEGORY_ALARM);

        Notification n = b.build();
        if (alarm) n.flags |= Notification.FLAG_INSISTENT;
        nm.notify(id == null ? 0 : id.hashCode(), n);
    }

    static void createChannels(NotificationManager nm) {
        if (nm.getNotificationChannel(CH_ALARM) == null) {
            NotificationChannel ch = new NotificationChannel(CH_ALARM, "الارم‌ها", NotificationManager.IMPORTANCE_HIGH);
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), aa);
            ch.enableVibration(true);
            ch.setVibrationPattern(new long[]{0, 500, 300, 500, 300, 500});
            nm.createNotificationChannel(ch);
        }
        if (nm.getNotificationChannel(CH_TASK) == null) {
            NotificationChannel ch = new NotificationChannel(CH_TASK, "یادآوری برنامه‌ها", NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        }
    }
}
